# Whatsapp Bot (Auto Chat AI)
 *  AI from Character.ai
 *  Pairing Code
 *  Support Private Chat & Group
 *  Mention untuk prefix chat grup
 

## Features
 * Rest API : https://api.maelyn.my.id

## Installation 

```bash
  $ apt update && apt upgrade -y
  $ apt install nodejs
  $ apt install git
  $ curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.1/install.sh | bash
  $ source ~/.nvm/nvm.sh
  $ nvm install 20
  $ nvm use 20
  $ node -v
  $ git clone https://github.com/ClayzaAubert/WA-Bot-Char-AI.git
  $ cd WA-Bot-Char-AI
  $ npm install
  $ npm install pm2
  $ node . (ambil sesi dahulu)
  $ ctrl + c
  $ pm2 start index.js --name bot
```
    
## License

[![MIT License](https://img.shields.io/badge/License-MIT-green.svg)](https://choosealicense.com/licenses/mit/)

## Authors

[@ClayzaAubert](https://github.com/@ClayzaAubert)
[@Arifzyn](https://github.com/Arifzyn19)

