const axios = require('axios');

const CHAR_ID = 'U3dJdreV9rrvUiAnILMauI-oNH838a8E_kEYfOFPalE';
const CHAT_ID = '2ab36a74-eab9-4104-93a4-f9f4d0374b33';
const API_KEY = 'bzOA9SuCww';
const BASE_URL = 'https://api.maelyn.my.id/api/cai-chat';

async function MealynAPI(query) {
    const apiUrl = `${BASE_URL}?q=${encodeURIComponent(query)}&charid=${CHAR_ID}&chatid=${CHAT_ID}&apikey=${API_KEY}`;

   try {

        const response = await axios.get(apiUrl, {

            headers: { 'Content-Type': 'application/json' },

        });

        return response.data.result.candidates[0].raw_content;

    } catch (error) {

        console.error('API Call Error:', error);

        throw error;

    }

} 

module.exports = MealynAPI
