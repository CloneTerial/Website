
document.addEventListener("DOMContentLoaded", function() {
    window.onload = function() {
        var loadingScreen = document.getElementById("loading-screen");
        var content = document.getElementById("content");

        // Hide the loading screen
        loadingScreen.style.display = "none";
        // Show the main content
        content.style.display = "block";
    };
});

   
        

  // Tambahkan event listener untuk klik
 